package inheritance;

public class Hierarch1 extends Hierarchical{
	
	
	void testing1() {
		
		System.out.println("Class 2");
	}

}

