package TestingCode;

 class Printtest {
	
	protected int x = 45;
	
	public void print() {
		
		System.out.println("Testing" + x);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Printtest obj = new Printtest();
		
		obj.print();
		
		
		//System.out.println("Testing");
	
	}

}
