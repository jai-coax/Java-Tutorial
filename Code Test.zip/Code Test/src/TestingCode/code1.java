package TestingCode;

public class code1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int test = 10; 
		
		System.out.println("Hello Jai..! Welcome Back." + "\n" + test );
		
		test = test + 10;  // 20
		
		System.out.println(test);
		
		test+=10;   //test = test + 10;  -- 30
		
		System.out.println(test);
		
		boolean result = test < 55; //? false : true;
		
		System.out.println(result);
		
	}

}
