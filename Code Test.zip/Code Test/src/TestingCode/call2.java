package TestingCode;

import codetest.sample;

public class call2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		sample a = new sample();
		
		a.test();
		System.out.println("sample " + a.x);
		a.x = 6;

	}

}
