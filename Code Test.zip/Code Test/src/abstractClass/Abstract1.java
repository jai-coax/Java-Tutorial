package abstractClass;

 abstract  class Abstract1 implements Interface { // Implementing interface in abstarct class
	 
	 				// Other methods are overided in chid class of current class -- This type overideing done only 
	 																			// in abstarct class


	@Override
	public void c() {
		System.out.println("I am C");
		
	}


}
