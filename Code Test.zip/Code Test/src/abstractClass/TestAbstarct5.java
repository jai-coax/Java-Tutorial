package abstractClass;

public class TestAbstarct5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Interface a=new ClassM();  
		a.a();  
		a.b();  
		a.c();  
		a.d();
		
		
		
		
	}

}
