package abstractClass;

abstract class Abstrac {
	
	// Explaination of Abstarct class -  it shows only important things to the user and 
	       //hides the internal details for example "Sending sms", 
	      //you just type the text and send the message. 
	      //You don't know the internal processing about the message delivery.
	
	// we can say Abstract is advance of interface 
	// in abstract class we can use two methods - abstract and Non-abstract method
	 // note : In interface we cannot use not abstract method but we can use in abstarct class
	
	
	abstract void run(); // abstract method -- this method should be overide in extended class
	
	
	void print() { // non-abstarct method 
		
		System.out.println("test class of abstract");
	}
	
	

}
