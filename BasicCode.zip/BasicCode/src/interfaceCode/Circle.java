package interfaceCode;

public class Circle implements Drawable {
	
	public void draw(){ // same method in rectangle class
		
		System.out.println("drawing circle");
		
	}

}
