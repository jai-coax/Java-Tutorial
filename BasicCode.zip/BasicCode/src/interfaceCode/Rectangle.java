package interfaceCode;

public class Rectangle implements Drawable {
	
	public void draw(){ // same method in cricle class
		
		System.out.println("drawing rectangle");
		
	}  

}
