package inheritance;

public class singleInhert extends Hierarchical {
	
	int test1 = 20;
	
	void sample() {
		
		System.out.println("class 1 execution");
	}
	
void testing() {
		
		System.out.println("class 1 method2  execution");
	}
	
/*	singleInhert(){
		
		System.out.println("class 1 constructor");
	}*/
	
}
