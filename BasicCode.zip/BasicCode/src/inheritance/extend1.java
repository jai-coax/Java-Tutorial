package inheritance;

public class extend1 extends multiInhert {
	
	
	int tester =12;
	
	void train() {
		

	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		extend1 q = new extend1();
		
		//System.out.println(q.test1);
		
		q.sample();
		
		q.train();
		
		
	}

}
