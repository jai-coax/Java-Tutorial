package inheritance;

public class Hierarchical {
	
	void sam() {
		
		System.out.println("Class Main");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hierarchical a =new Hierarchical();
		
		

	}

}
