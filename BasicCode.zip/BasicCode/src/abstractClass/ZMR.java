package abstractClass;

public class ZMR extends Bike {

	@Override
	int getRateOfInterest() {
		// TODO Auto-generated method stub
		return 9;
	}

	@Override
	void run() {
		// TODO Auto-generated method stub
		System.out.println("running fast..");
	}

}
