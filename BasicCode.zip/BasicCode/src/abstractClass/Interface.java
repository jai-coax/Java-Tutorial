package abstractClass;

 interface Interface {
	 
	 void a();  
	 void b();  
	 void c();  
	 void d();

}
