package abstractClass;

 class Honda extends Bike{

	@Override
	int getRateOfInterest() {
		// TODO Auto-generated method stub
		return 7;
	}

	@Override
	void run() {
		
		System.out.println("running safely..");
		
	}
	 
}
