package abstractClass;

abstract class testAbstrac {
	
	
	void test() {
		
		System.out.println();
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		testAbstrac a = new testAbstrac(); // We cannot able to create object for abstarct class
		
		
	}

}
