package TestingCode;

public class construtor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// IF Method Name and Class name are same then it is constructor.
		// If Method name and Class name are different then it is method.
		
		// Contructor only execute first execute after then only main method(Public static void main) will execute in an program
		
		// Mutiple constructor can be created in single class but those constructor should be parameterize with differnent
		
		
		// When your executing the contructor in main method(Public static void main) by extended class , the construtor
		// avalible in both class1 and extended class will be executed.(example program in Superkeyword)
		

	}

}
